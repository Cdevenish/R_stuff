## Day/Month/Year
## Testing for differences in 3+ groups - ANOVA
## YOUR NAME


## Delete all existing objects in the environment before starting
rm(list=ls())


# set working directory - tells R-Studio where to read and save files 
setwd("H:/Documents/How Science Works/Anova")


##################################################################

# More than two groups: ANOVA 

# 1. Null hypothesis: 
# There is no significant difference in sepal width between the the three iris species.

# 2. Load data for working directory 
sepal<-read.csv("iris_sepal.csv")

# 3. Explore data: Look at the structure of the dataset
str(sepal)

# Look at the dataset column names 
names(sepal)

# Look at a summary (min,max,mean...) of the data 
summary(sepal)

# Use the tapply function to calculate the mean and the sd of groups:
tapply(sepal$Sepal.Width, sepal$Species, FUN=mean)
tapply(sepal$Sepal.Width, sepal$Species, FUN=sd)

## 4. Plot data: Boxplot for iris data
hist(sepal$Sepal.Width)

boxplot(sepal$Sepal.Width ~ sepal$Species)

# 5. Test data: ANOVA to test for differences three+ groups
sepal_anova <- aov(Sepal.Width ~ Species, data=sepal)
summary(sepal_anova)

# 5. Test data: To find out which groups are different we need to do a post hoc test 
# In R we can use the TukeyHSD function for this
TukeyHSD(sepal_anova)

## 6. Report results: 

# There was a significant difference in sepal width (mm) between the three iris 
# species (F=49.2, DF=2,147, P<0.001). Setosa sepal width was significantly greater
# than all other species (mean= 3.4, sd= 0.4), while versicolor was less than all 
# other species (mean= 2.8, SD= 0.3).

png("iris_sepal_width.png")
boxplot(sepal$Sepal.Width ~ sepal$Species, ylab="Sepal width (mm)", xlab = "Iris species")
dev.off()

##################################################################
