## Day/Month/Year
## Testing for relationships - CORRELATIONS
## YOUR NAme


## Delete all existing objects in the environment before starting
rm(list=ls())

# set working directory - tells R-Studio where to read and save files 
setwd("H:/Documents/How Science Works/Correlation")

##################################################################
##################################################################

# Non-causal relationship 
# Correlation 
# 1. Null hypothesis: there is no significant relationship between the amount spent 
#    on coffee and vehicle fuel efficiency

# 2. Load data
drivers<-read.csv("drivers.csv")

# 3. Explore data: Look at the structure of the dataset
str(drivers)

# Look at the dataset column names 
names(drivers)

# Look at a summary (min,max,mean...) of the data 
summary(drivers)

mean(drivers$fuel)

sd(drivers$fuel)
sd(drivers$coffee)

# 4. Plot data: Scatter plot for relationships
hist(drivers$fuel)
hist(drivers$coffee)

plot(drivers$fuel, drivers$coffee)

# 5. Test data: correlation for non-causal relationships
cor.test(drivers$fuel, drivers$coffee)

# 6. Report results: There was a strong negative relationship between fuel efficiency 
# and amount (in pounds sterling) spent of drivers coffee (r=-0.87, P<0.001, df = 30)

png("drivers_fuel.png")
plot(drivers$fuel ~ drivers$coffee, xlab="Amount spent on coffee (�)", pch=19, col="black", ylab="Fuel efficiency (mpg)")
dev.off()

##########################