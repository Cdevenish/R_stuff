# Date
# Your Name
# Analysis: tests for differences: t-test

# clears r console
rm(list=ls())

# set working directory 
setwd("PUT FOLDER PATH HERE") # e.g "D:/Documents/Classes/R_Stats"
# Remember to change back slashes to forward slashed on Windows

# check working directory
getwd()

# list of files in working directory
list.files()


##################################################################################################



# Two groups: male and female Elephant weights
# Normally distributed
# T-test
## 1. Null Hypothesis: There is no difference in weight between male and female elephants

## 2. Load data: load external data 
ele <- read.csv("elephants.csv")

## 3. Explore data: Look at the structure of the dataset
str(ele)

# Look at the dataset column names 
names(ele)

# Look at a summary (min,max,mean...) of the data 
summary(ele)

# Look at the distribution of the continuous variable 
par(mfrow = c(1,2))
tapply(ele$weight, ele$sex, hist)
par(mfrow = c(1,1))

# Use the tapply function to calculate the mean and the sd of groups:
tapply(ele$weight, ele$sex, mean)
tapply(ele$weight, ele$sex, sd)

## 4. Plot data: Boxplot for t-test
boxplot(weight ~ sex, data = ele)

## 5. Test data: t-test for differences between two groups
t.test(weight ~ sex, data = ele) 


## 6. Report results and present data.......
# t = -77.01, df = 57.849, p-value < 2.2e-16

tapply(ele$weight, ele$sex, mean)
tapply(ele$weight, ele$sex, sd)

# Mean
# female     male 
# 3173.459 5913.033 

# SD
# female     male 
# 134.2118 141.2539


png("elephant_weight.png", width = 150, height = 100, units = "mm", res = 100)
boxplot(weight ~ sex, data = ele, xlab = "Sex", ylab = "Weight (kg)")
dev.off()

